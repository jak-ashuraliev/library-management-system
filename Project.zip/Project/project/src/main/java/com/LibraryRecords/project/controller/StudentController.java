package com.LibraryRecords.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.LibraryRecords.project.model.Students;
import com.LibraryRecords.project.service.StudentService;

@Controller

public class StudentController {
	
	 @Autowired
	    private StudentService studentService;

	    @GetMapping("/showStudents")
	    public String findStudents(Model model) {

	        var students = (List<Students>) studentService.findAll();

	        model.addAttribute("students", students);

	        return "showStudents";
	    }

}
