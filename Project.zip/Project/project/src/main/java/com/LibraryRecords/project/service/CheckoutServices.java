package com.LibraryRecords.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryRecords.project.model.Checkout;
import com.LibraryRecords.project.repository.CheckoutRepository;



@Service
public class CheckoutServices implements CheckoutService{
	
	
	 @Autowired
	    private CheckoutRepository repository;

	    @Override
	    public List<Checkout> findAll() {

	        var checkout = (List<Checkout>) repository.findAll();

	        return checkout;
	    }
	
	

}
