package com.LibraryRecords.project.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.LibraryRecords.project.model.Returns;




@Repository

public interface ReturnsRepository extends CrudRepository<Returns, Long>{
	
	
	
	

}
