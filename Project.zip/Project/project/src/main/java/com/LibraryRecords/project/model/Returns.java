package com.LibraryRecords.project.model;

import java.sql.Date;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "returns")
public class Returns {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    
	    private Long returnid;
	    private int checkoutid;
	    private Date checkindate;
	    private Date returndate;
	    
	    

	    public Returns() {
	    }

	    public Returns(Long returnid, int checkoutid, Date returndate, 
	    		Date checkindate) {
	    	
	    	this.returnid = returnid;
	    	this.checkoutid =checkoutid;
	        this.returndate = returndate;
	        this.checkindate = checkindate;
	        
	    }

	    public Long getReturnid() {
	        return returnid;
	    }

	    public int getCheckoutid() {
	        return checkoutid;
	    }

	    public void setCheckoutid(int checkoutid) {
	        this.checkoutid = checkoutid;
	    }
	    public Date getReturndate() {
	        return returndate;
	    }

	    public void setReturndate(Date returndate) {
	        this.returndate = returndate;
	    }
	    
	    
	    public Date getCheckindate() {
	        return checkindate;
	    }

	    public void setCheckindate(Date checkindate ) {
	        this.checkindate = checkindate;
	    }
	    
	    
	    

	    @Override
	    public int hashCode() {
	        int hash = 7;
	        hash = 79 * hash + Objects.hashCode(this.returnid);
	        hash = 79 * hash + Objects.hashCode(this.returndate);
	        hash = 79 * hash + Objects.hashCode(this.checkoutid);
	        hash = 79 * hash + Objects.hashCode(this.checkindate);
	        
	        
	        return hash;
	    }

	    @Override
	    public boolean equals(Object obj) {
	        if (this == obj) {
	            return true;
	        }
	        if (obj == null) {
	            return false;
	        }
	        if (getClass() != obj.getClass()) {
	            return false;
	        }
	        final Returns other = (Returns) obj;
	        if (this.checkoutid != other.checkoutid) {
	            return false;
	        }
	        if (this.checkindate != other.checkindate) {
	            return false;
	        }
	        if (!Objects.equals(this.returndate, other.returndate)) {
	            return false;
	        }
	        
	        return Objects.equals(this.returnid, other.returnid);
	    }

	    @Override
	    public String toString() {
	        final StringBuilder sb = new StringBuilder("Returns{");
	        sb.append("returnid=").append(returnid);
	        sb.append(", checkoutid='").append(checkoutid).append('\'');
	        sb.append(", returndate=").append(returndate);
	        sb.append(", checkindate=").append(checkindate);
	        sb.append('}');
	        return sb.toString();
	    }
	

}
