package com.LibraryRecords.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryRecords.project.model.Books;
import com.LibraryRecords.project.repository.BookRepository;

@Service
public class BookServices implements BookService{
	
	
	 @Autowired
	    private BookRepository repository;

	    @Override
	    public List<Books> findAll() {

	        var books = (List<Books>) repository.findAll();

	        return books;
	    }
	
	

}
