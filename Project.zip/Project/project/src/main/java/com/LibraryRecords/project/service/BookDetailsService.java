package com.LibraryRecords.project.service;

import java.util.List;

import com.LibraryRecords.project.model.BookDetails;

public interface BookDetailsService {
	
	List<BookDetails> findAll();

}
