package com.LibraryRecords.project.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.LibraryRecords.project.model.BookDetails;

@Repository

public interface BookDetailsRepository extends CrudRepository<BookDetails, Long>{
	
	

}
