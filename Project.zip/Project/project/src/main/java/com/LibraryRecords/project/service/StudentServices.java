package com.LibraryRecords.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryRecords.project.model.Students;
import com.LibraryRecords.project.repository.StudentRepository;

@Service

public class StudentServices implements StudentService {
	
	@Autowired
    private StudentRepository repository;

    @Override
    public List<Students> findAll() {

        var students = (List<Students>) repository.findAll();

        return students;
    }
	
	

}
