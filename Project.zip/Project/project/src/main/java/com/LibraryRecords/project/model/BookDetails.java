package com.LibraryRecords.project.model;

import java.math.BigInteger;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bookdetail")

public class BookDetails {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long bookdetailid;
  
	private int bookid;
    private String genre;
    private String publisher;
    private BigInteger isbn;
	
    public BookDetails() {
    }

    public BookDetails(Long bookdetailid, int bookid, String genre, 
    		String publisher,BigInteger isbn) {

        this.bookdetailid = bookdetailid;
        this.bookid = bookid;
        this.genre = genre;
        this.publisher = publisher;
        this.isbn = isbn;
        
    }

    public Long getBookdetailid() {
        return bookdetailid;
    }

    public int getBookid() {
        return bookid;
    }
    public void setBookid(int bookid) {
        this.bookid = bookid;
   }
    
    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
    
    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    
    
    

    public BigInteger getIsbn() {
        return isbn;
    }

    public void setIsbn( BigInteger isbn) {
        this.isbn = isbn;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + Objects.hashCode(this.bookdetailid);
        hash = 79 * hash + Objects.hashCode(this.bookid);
        hash = 79 * hash + Objects.hashCode(this.genre);
        hash = 79 * hash + Objects.hashCode(this.publisher);
        hash = 79 * hash + Objects.hashCode(this.isbn);
        return hash;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BookDetails other = (BookDetails) obj;
        if (this.isbn != other.isbn) {
            return false;
        }
        if (!Objects.equals(this.publisher, other.publisher)) {
            return false;
            
        }
        if (!Objects.equals(this.genre, other.genre)) {
        	
        
                return false;
                
                
        }
        
        if (!Objects.equals(this.bookid, other.bookid)) {
        	
        return false;
        }
        return Objects.equals(this.bookdetailid, other.bookdetailid);
    
        
    }
        
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("BookDetails{");
        sb.append("bookdetailid=").append(bookdetailid);
        sb.append("bookid=").append(bookid);
        sb.append(", genre='").append(genre).append('\'');
        sb.append(", publisher=").append(publisher);
        sb.append(", isbn=").append(isbn);
        sb.append('}');
        return sb.toString();
    }
    
    
}
    

