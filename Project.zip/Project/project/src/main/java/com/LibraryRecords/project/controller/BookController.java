package com.LibraryRecords.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.LibraryRecords.project.model.BookDetails;
import com.LibraryRecords.project.model.Books;
import com.LibraryRecords.project.service.BookDetailsService;
import com.LibraryRecords.project.service.BookService;

@Controller
public class BookController {
	

	@Autowired
    private BookService bookService;
	
	@Autowired
    private BookDetailsService bookDetailsService;

  @GetMapping("/showBooks")
   public String findBooks(Model model) {

       var books = (List<Books>) bookService.findAll();
       model.addAttribute("books", books);
       
       var bookdetail = (List<BookDetails>) bookDetailsService.findAll();
       model.addAttribute("bookdetail", bookdetail);
       

      return "showBooks";
    }
	
	

}
