package com.LibraryRecords.project.service;

import java.util.List;

import com.LibraryRecords.project.model.Returns;





public interface ReturnsService {
	
	
	List<Returns> findAll();
	
	

}
