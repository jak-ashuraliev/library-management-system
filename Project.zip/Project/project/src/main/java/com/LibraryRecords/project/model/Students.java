package com.LibraryRecords.project.model;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "students")
public class Students {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long studentid;

	    private String firstname;
	    private String lastname;
	    private String outstandingfee;
	    private String studentemail;

	    public Students() {
	    }

	    public Students(Long studentid, String firstname, String lastname, 
	    		String outstandingfee,String studentemail ) {

	        this.studentid = studentid;
	        this.firstname = firstname;
	        this.lastname = lastname;
	        this.outstandingfee = outstandingfee;
	        this.studentemail =studentemail;
	    }

	    public Long getStudentid() {
	        return studentid;
	    }

	    public String getFirstname() {
	        return firstname;
	    }

	    public void setFirstname(String firstname) {
	        this.firstname = firstname;
	    }
	    public String getLastname() {
	        return lastname;
	    }

	    public void setLastname(String lastname) {
	        this.lastname = lastname;
	    }
	    
	    
	    public String getOutstandingfee() {
	        return outstandingfee;
	    }

	    public void setOutstandingfee(String outstandingfee ) {
	        this.outstandingfee = outstandingfee;
	    }
	    
	    public String getStudentemail() {
	        return studentemail;
	    }

	    public void setStudentemail(String studentemail ) {
	        this.studentemail = studentemail;
	    }
	    

	    @Override
	    public int hashCode() {
	        int hash = 7;
	        hash = 79 * hash + Objects.hashCode(this.studentid);
	        hash = 79 * hash + Objects.hashCode(this.firstname);
	        hash = 79 * hash + Objects.hashCode(this.lastname);
	        hash = 79 * hash + Objects.hashCode(this.outstandingfee);
	        hash = 79 * hash + Objects.hashCode(this.studentemail);
	        
	        return hash;
	    }

	    @Override
	    public boolean equals(Object obj) {
	        if (this == obj) {
	            return true;
	        }
	        if (obj == null) {
	            return false;
	        }
	        if (getClass() != obj.getClass()) {
	            return false;
	        }
	        final Students other = (Students) obj;
	        if (this.studentemail != other.studentemail) {
	            return false;
	        }
	        if (this.outstandingfee != other.outstandingfee) {
	            return false;
	        }
	        if (!Objects.equals(this.lastname, other.lastname)) {
	            return false;
	        }
	        
	        if (!Objects.equals(this.firstname, other.firstname)) {
	            return false;
	        }
	        return Objects.equals(this.studentid, other.studentid);
	    }

	    @Override
	    public String toString() {
	        final StringBuilder sb = new StringBuilder("Students{");
	        sb.append("studentid=").append(studentid);
	        sb.append(", firstname='").append(firstname).append('\'');
	        sb.append(", lastname=").append(lastname);
	        sb.append(", outstandingfee=").append(outstandingfee);
	        sb.append(", studentemail=").append(studentemail);
	        sb.append('}');
	        return sb.toString();
	    }
	

}
