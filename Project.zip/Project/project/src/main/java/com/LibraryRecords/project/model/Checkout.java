package com.LibraryRecords.project.model;

import java.sql.Date;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "checkout")
public class Checkout {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long checkoutid;

	    private int studentid;
	    private int bookid;
	    private Date checkoutdate;
	    

	    public Checkout() {
	    }

	    public Checkout(Long checkoutid,int studentid,int bookid, Date checkoutdate) {

	    	this.checkoutid =checkoutid;
	        this.studentid = studentid;
	        this.bookid = bookid;
	        this.checkoutdate = checkoutdate;
	        
	    }

	    public Long getCheckoutid() {
	        return checkoutid;
	    }

	    public int getStudentid() {
	        return studentid;
	    }

	    public void setStudentid(int studentid) {
	        this.studentid = studentid;
	    }
	    public int getBookid() {
	        return bookid;
	    }

	    public void setBookid(int bookid) {
	        this.bookid = bookid;
	    }
	    
	    
	    public Date getCheckoutdate() {
	        return checkoutdate;
	    }

	    public void setCheckoutdate(Date checkoutdate ) {
	        this.checkoutdate = checkoutdate;
	    }
	    
	    
	    

	    @Override
	    public int hashCode() {
	        int hash = 7;
	        hash = 79 * hash + Objects.hashCode(this.studentid);
	        hash = 79 * hash + Objects.hashCode(this.bookid);
	        hash = 79 * hash + Objects.hashCode(this.checkoutid);
	        hash = 79 * hash + Objects.hashCode(this.checkoutdate);
	        
	        
	        return hash;
	    }

	    @Override
	    public boolean equals(Object obj) {
	        if (this == obj) {
	            return true;
	        }
	        if (obj == null) {
	            return false;
	        }
	        if (getClass() != obj.getClass()) {
	            return false;
	        }
	        final Checkout other = (Checkout) obj;
	        if (this.checkoutid != other.checkoutid) {
	            return false;
	        }
	        if (this.checkoutdate != other.checkoutdate) {
	            return false;
	        }
	        if (!Objects.equals(this.bookid, other.bookid)) {
	            return false;
	        }
	        
	        return Objects.equals(this.studentid, other.studentid);
	    }

	    @Override
	    public String toString() {
	        final StringBuilder sb = new StringBuilder("Checkout{");
	        sb.append("studentid=").append(studentid);
	        sb.append(", checkoutid='").append(checkoutid).append('\'');
	        sb.append(", bookid=").append(bookid);
	        sb.append(", checkoutdate=").append(checkoutdate);
	        sb.append('}');
	        return sb.toString();
	    }
	

}
