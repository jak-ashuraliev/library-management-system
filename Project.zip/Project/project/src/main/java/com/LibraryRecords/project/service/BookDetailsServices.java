package com.LibraryRecords.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryRecords.project.model.BookDetails;
import com.LibraryRecords.project.repository.BookDetailsRepository;

@Service
public class BookDetailsServices implements BookDetailsService{
	
	
	
	@Autowired
    private BookDetailsRepository repository;

    @Override
    public List<BookDetails> findAll() {

        var bookdetail = (List<BookDetails>) repository.findAll();

        return bookdetail;
    }

}
