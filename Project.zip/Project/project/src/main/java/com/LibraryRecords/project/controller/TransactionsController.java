package com.LibraryRecords.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.LibraryRecords.project.model.Checkout;
import com.LibraryRecords.project.model.Returns;
import com.LibraryRecords.project.service.CheckoutService;
import com.LibraryRecords.project.service.ReturnsService;



@Controller
public class TransactionsController {
	

	@Autowired
    private CheckoutService checkoutService;
	
	@Autowired
    private ReturnsService returnsService;

  @GetMapping("/showTransactions")
   public String findTransactions(Model model) {

       var checkout = (List<Checkout>) checkoutService.findAll();
       model.addAttribute("checkout", checkout);
       
       var returns = (List<Returns>) returnsService.findAll();
       model.addAttribute("returns", returns);
       

      return "showTransactions";
    }
	
	

}
