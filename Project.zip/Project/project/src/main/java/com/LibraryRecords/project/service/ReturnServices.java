package com.LibraryRecords.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryRecords.project.model.Returns;
import com.LibraryRecords.project.repository.ReturnsRepository;



@Service

public class ReturnServices implements ReturnsService {
	
	@Autowired
    private ReturnsRepository repository;

    @Override
    public List<Returns> findAll() {

        var returns = (List<Returns>) repository.findAll();

        return returns;
    }
	
	

}
