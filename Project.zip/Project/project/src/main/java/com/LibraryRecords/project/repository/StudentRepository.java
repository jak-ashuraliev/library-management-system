package com.LibraryRecords.project.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.LibraryRecords.project.model.Students;

@Repository

public interface StudentRepository extends CrudRepository<Students, Long> {
	
	

}
