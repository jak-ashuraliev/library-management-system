package com.LibraryRecords.project.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.LibraryRecords.project.model.Books;

@Repository

public interface BookRepository extends CrudRepository<Books, Long>{
	
	
	
	

}
