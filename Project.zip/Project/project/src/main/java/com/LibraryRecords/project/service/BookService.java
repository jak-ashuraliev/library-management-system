package com.LibraryRecords.project.service;

import java.util.List;

import com.LibraryRecords.project.model.Books;

public interface BookService {
	
	
	List<Books> findAll();
	
	

}
